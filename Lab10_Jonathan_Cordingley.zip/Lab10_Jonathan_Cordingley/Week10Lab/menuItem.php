<?php

//$object = new menuItem;

class MenuItem
{
    private $itemName;
    private $description;
    private $price;

    function __construct($itemName, $description, $price){
        $this->itemName = $itemName;
        $this->description = $description;
        $this->price = $price;
    } 

    function get_ItemName(){
        return $this->itemName;
        
    }

    function set_ItemName($name){
        $this->itemName = $name;
    }

    function get_Description(){
        return $this->description;
    }

    function set_Description($desc){
        $this->description = $desc;
    }

    function get_Price(){
        return $this->price;
    }

    function set_Price($pri){
        $this->price = $pri;
    }

}

?>