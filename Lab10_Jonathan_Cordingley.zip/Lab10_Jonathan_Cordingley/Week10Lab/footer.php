<footer>
                <p>&copy; <?php echo date("Y"); ?> CST8285. All Rights Reserved.</p>
            </footer>
        </div><!-- End Wrapper  this dv is included in footer.php-->
    </body>